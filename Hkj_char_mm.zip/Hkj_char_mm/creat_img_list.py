import os
from os import listdir, getcwd
from os.path import join
from optparse import OptionParser

parser = OptionParser()
parser.add_option("-i", "--path", dest="xml_path", help="Path to XML file",
                  default=r"D:\share\models\TT\HLearn\HHHH_DATA_HHHH\STEEL_PLATE_Segment\char_mm\Annotations")
parser.add_option("-o", "--filename", dest="out_filename", help="name of output file", default="trainval.txt")

(options, args) = parser.parse_args()

if __name__ == '__main__':
    xml_path = options.xml_path
    out_filename = options.out_filename
    file_list = os.listdir(xml_path)
    write_file = open(out_filename, 'a')
    for file_obj in file_list:
        file_name, file_extend = os.path.splitext(file_obj)
        # file_num=int(file_name)
        write_file.write(file_name + '\n')
    write_file.close()
