import os
import cv2
import numpy as np
from os import listdir, getcwd
from os.path import join
from optparse import OptionParser

parser = OptionParser()
parser.add_option("-i", "--path", dest="img_path", help="Path to IMG file",
                  default=r"D:\share\models\TT\HLearn\HHHH_DATA_HHHH\STEEL_PLATE_Segment\char_m\JPEGImages")

(options, args) = parser.parse_args()

if __name__ == '__main__':
    img_path = options.img_path
    file_list = os.listdir(img_path)
    g_mean=0
    g_std=0
    g_n=0
    for file in file_list:
        img_name=os.path.join(img_path,file)
        print(img_name)
        img=cv2.imread(img_name,0)
        _, thresh = cv2.threshold(img, 1, 255, 0)
        img=img/255.
        #cv2.imshow("ss",thresh)
        #cv2.waitKey(0)
        (mean, std) = cv2.meanStdDev(img,mask=thresh)
        g_mean=g_mean+mean[0][0]
        g_std=g_std+std[0][0]
        g_n=g_n+1
    g_mean=g_mean/g_n
    g_std=g_std/g_n
    print(g_mean*255)
    print("均值：",g_mean,"标准差：",g_std)
